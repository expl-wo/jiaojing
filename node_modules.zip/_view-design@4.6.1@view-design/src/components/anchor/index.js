import Anchor from './anchor.vue';
export default Anchor;
