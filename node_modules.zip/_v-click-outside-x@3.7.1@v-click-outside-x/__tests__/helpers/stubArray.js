export default function stubArray() {
  return [];
}
