import Card from './card.vue';
export default Card;