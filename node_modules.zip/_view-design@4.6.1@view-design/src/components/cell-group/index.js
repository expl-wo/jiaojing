import CellGroup from '../cell/cell-group.vue';
export default CellGroup;