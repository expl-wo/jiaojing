export default function nilSubjects() {
  return [undefined, void 0, null];
}
