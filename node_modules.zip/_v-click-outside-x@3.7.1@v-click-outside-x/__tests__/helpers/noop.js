export default function noop() {
  return void 0;
}
