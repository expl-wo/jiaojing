var AwaitValue = require("./AwaitValue.js");

function _awaitAsyncGenerator(value) {
  return new AwaitValue(value);
}

module.exports = _awaitAsyncGenerator;
module.exports["default"] = module.exports, module.exports.__esModule = true;