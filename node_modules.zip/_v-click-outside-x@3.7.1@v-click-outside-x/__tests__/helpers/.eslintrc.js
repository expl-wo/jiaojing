module.exports = {
  rules: {
    'no-void': 'off',
  },
};
