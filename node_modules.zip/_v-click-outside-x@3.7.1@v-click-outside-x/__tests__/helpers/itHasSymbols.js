export default (typeof Symbol === 'function' && typeof Symbol('') === 'symbol'
  ? it
  : xit);
